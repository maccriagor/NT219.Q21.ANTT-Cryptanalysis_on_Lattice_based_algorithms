/**
 * ECC secp521r1 FULL BENCHMARK - NT219 Capstone
 * NIST Level 5 equivalent security
 *
 * Benchmarks:
 *   - ECDSA Keygen        (signing keypair)
 *   - ECDH Amy side       (ephemeral keypair + shared secret) ← encap equivalent
 *   - ECDH Bob side       (shared secret from Amy's public)   ← decap equivalent
 *   - ECDSA Sign          (SHA-512)
 *   - ECDSA Verify        (SHA-512)
 *
 * Output format (stdout, one line):
 *   DATA:kg_cyc,kg_ns,ecdh_a_cyc,ecdh_a_ns,ecdh_b_cyc,ecdh_b_ns,sig_cyc,sig_ns,ver_cyc,ver_ns
 */

#include <openssl/ec.h>
#include <openssl/ecdh.h>
#include <openssl/ecdsa.h>
#include <openssl/evp.h>
#include <openssl/obj_mac.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <openssl/err.h>

#include <chrono>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#ifdef __linux__
#include <sched.h>
#endif

// -----------------------------------------------------------------------
// Constants
// -----------------------------------------------------------------------
#define CURVE_NID      NID_secp521r1
#define MSG_BYTES      64          // SHA-512 digest size used for signing

// -----------------------------------------------------------------------
// Benchmarking — exact same pattern as the Kyber program
// -----------------------------------------------------------------------
struct BenchResult {
    uint64_t cycles;
    long long ns;
};

static inline void serialize() {
    unsigned int a, b, c, d;
    __asm__ __volatile__("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "a"(0));
}

static inline uint64_t get_cycles() {
    unsigned int lo, hi;
    __asm__ __volatile__("rdtsc" : "=a"(lo), "=d"(hi));
    return ((uint64_t)hi << 32) | lo;
}

template<typename Func>
BenchResult measure(Func f) {
    auto t_start = std::chrono::high_resolution_clock::now();

    serialize();
    uint64_t c_start = get_cycles();
    serialize();

    f();

    serialize();
    uint64_t c_end = get_cycles();
    serialize();

    auto t_end = std::chrono::high_resolution_clock::now();

    return {
        (c_end - c_start),
        std::chrono::duration_cast<std::chrono::nanoseconds>(t_end - t_start).count()
    };
}

// -----------------------------------------------------------------------
// Helper: create a fresh EC_KEY on secp521r1 and generate keypair
// -----------------------------------------------------------------------
static EC_KEY* make_keypair() {
    EC_KEY* key = EC_KEY_new_by_curve_name(CURVE_NID);
    if (!key) throw std::runtime_error("EC_KEY_new_by_curve_name failed");
    if (EC_KEY_generate_key(key) != 1) {
        EC_KEY_free(key);
        throw std::runtime_error("EC_KEY_generate_key failed");
    }
    return key;
}

// -----------------------------------------------------------------------
// Helper: ECDH — compute shared secret given own private key and peer public key
// Returns shared secret length, fills out_secret (caller allocates field_size bytes)
// -----------------------------------------------------------------------
static size_t ecdh_compute(EC_KEY* own_key, const EC_POINT* peer_pub,
                            unsigned char* out_secret, size_t secret_len) {
    int len = ECDH_compute_key(out_secret, secret_len, peer_pub, own_key, nullptr);
    if (len <= 0) throw std::runtime_error("ECDH_compute_key failed");
    return (size_t)len;
}

// -----------------------------------------------------------------------
// KDF: SHA-256 over the ECDH shared secret → 32-byte AES key
// Same pattern as the Kyber program
// -----------------------------------------------------------------------
static bool KDF(const unsigned char* ss, size_t ss_len, unsigned char* k_enc) {
    unsigned int len = 0;
    return EVP_Digest(ss, ss_len, k_enc, &len, EVP_sha256(), nullptr) == 1;
}

// -----------------------------------------------------------------------
// AES-256-GCM Encrypt — same as Kyber program
// -----------------------------------------------------------------------
static bool aes_gcm_encrypt(const unsigned char* key,
                             const unsigned char* plaintext, int pt_len,
                             unsigned char* ciphertext,
                             unsigned char* iv, unsigned char* tag) {
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    int len;
    if (!ctx) return false;
    if (RAND_bytes(iv, 12) != 1) return false;
    if (EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), nullptr, nullptr, nullptr) != 1) return false;
    if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, 12, nullptr) != 1) return false;
    if (EVP_EncryptInit_ex(ctx, nullptr, nullptr, key, iv) != 1) return false;
    if (EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, pt_len) != 1) return false;
    if (EVP_EncryptFinal_ex(ctx, ciphertext + len, &len) != 1) return false;
    if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, 16, tag) != 1) return false;
    EVP_CIPHER_CTX_free(ctx);
    return true;
}

// -----------------------------------------------------------------------
// AES-256-GCM Decrypt — same as Kyber program
// -----------------------------------------------------------------------
static bool aes_gcm_decrypt(const unsigned char* key,
                             const unsigned char* ciphertext, int ct_len,
                             const unsigned char* iv, const unsigned char* tag,
                             unsigned char* plaintext) {
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    int len, ret;
    if (!ctx) return false;
    if (EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), nullptr, nullptr, nullptr) != 1) goto err;
    if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, 12, nullptr) != 1) goto err;
    if (EVP_DecryptInit_ex(ctx, nullptr, nullptr, key, iv) != 1) goto err;
    if (EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ct_len) != 1) goto err;
    if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, 16, (void*)tag) != 1) goto err;
    ret = EVP_DecryptFinal_ex(ctx, plaintext + len, &len);
    EVP_CIPHER_CTX_free(ctx);
    return ret > 0;
err:
    EVP_CIPHER_CTX_free(ctx);
    return false;
}

// -----------------------------------------------------------------------
// main
// -----------------------------------------------------------------------
int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

#ifdef __linux__
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(0, &cpuset);
    sched_setaffinity(0, sizeof(cpuset), &cpuset);
#endif

    // secp521r1 field size = ceil(521/8) = 66 bytes
    const size_t field_size = 66;

    // -----------------------------------------------------------------------
    // STEP 1 — ECDSA KEYGEN (Bob's long-term signing keypair)
    // This is what gets signed and sent, equivalent to Kyber keygen
    // -----------------------------------------------------------------------
    EC_KEY* sign_key = nullptr;

    BenchResult kg_data = measure([&]() {
        sign_key = make_keypair();
    });

    // -----------------------------------------------------------------------
    // STEP 2 — ECDH AMY SIDE (encap equivalent)
    //
    // Amy:
    //   1. generates ephemeral keypair
    //   2. computes shared secret using Bob's long-term public key
    //   3. sends her ephemeral public key to Bob
    //
    // Bob's long-term KEM keypair (reuse sign_key public for simplicity,
    // in a real protocol Bob would have a separate KEM keypair)
    // -----------------------------------------------------------------------
    EC_KEY* bob_kem_key = make_keypair();   // Bob's static KEM keypair
    EC_KEY* amy_ephemeral = nullptr;
    unsigned char ss_amy[66];
    size_t ss_amy_len = 0;

    BenchResult ecdh_a_data = measure([&]() {
        // Amy generates ephemeral keypair
        amy_ephemeral = make_keypair();

        // Amy computes shared secret using Bob's public key
        ss_amy_len = ecdh_compute(
            amy_ephemeral,
            EC_KEY_get0_public_key(bob_kem_key),
            ss_amy, field_size
        );
    });

    // -----------------------------------------------------------------------
    // STEP 3 — ECDH BOB SIDE (decap equivalent)
    //
    // Bob:
    //   1. receives Amy's ephemeral public key
    //   2. computes shared secret using his private key
    //   → same shared secret as Amy's
    // -----------------------------------------------------------------------
    unsigned char ss_bob[66];
    size_t ss_bob_len = 0;

    BenchResult ecdh_b_data = measure([&]() {
        ss_bob_len = ecdh_compute(
            bob_kem_key,
            EC_KEY_get0_public_key(amy_ephemeral),
            ss_bob, field_size
        );
    });

    // Sanity check: both sides must have the same shared secret
    if (ss_amy_len != ss_bob_len || memcmp(ss_amy, ss_bob, ss_amy_len) != 0) {
        std::cerr << "[ERROR] ECDH shared secrets do not match!\n";
        return -1;
    }

    // -----------------------------------------------------------------------
    // STEP 4 — KDF + AES-256-GCM ENCRYPT (Amy's side)
    // Derive AES key from shared secret, encrypt user input message
    // -----------------------------------------------------------------------
    std::string message;
    std::getline(std::cin, message);
    int message_len = (int)message.size();

    unsigned char k_enc_amy[32];
    KDF(ss_amy, ss_amy_len, k_enc_amy);

    std::vector<unsigned char> ciphertext(message_len);
    unsigned char iv[12];
    unsigned char tag[16];
    aes_gcm_encrypt(k_enc_amy,
                    reinterpret_cast<const unsigned char*>(message.data()),
                    message_len, ciphertext.data(), iv, tag);

    // -----------------------------------------------------------------------
    // STEP 5 — KDF + AES-256-GCM DECRYPT (Bob's side)
    // -----------------------------------------------------------------------
    unsigned char k_enc_bob[32];
    KDF(ss_bob, ss_bob_len, k_enc_bob);

    std::vector<unsigned char> decrypted(message_len);
    bool dec_ok = aes_gcm_decrypt(k_enc_bob, ciphertext.data(), message_len,
                                   iv, tag, decrypted.data());
    if (!dec_ok) {
        std::cerr << "[ERROR] AES-GCM decryption/tag verification failed!\n";
        return -1;
    }

    // -----------------------------------------------------------------------
    // STEP 6 — ECDSA SIGN (Bob signs his KEM public key, SHA-512)
    // Equivalent to Dilithium sign in the Kyber program
    // -----------------------------------------------------------------------
    unsigned char msg[MSG_BYTES];
    RAND_bytes(msg, MSG_BYTES);

    // Compute SHA-512 hash of message
    unsigned char msg_hash[SHA512_DIGEST_LENGTH];
    SHA512(msg, MSG_BYTES, msg_hash);

    std::vector<unsigned char> signature;
    unsigned int sig_len = 0;

    BenchResult sig_data = measure([&]() {
        int max_sig = ECDSA_size(sign_key);
        signature.resize(max_sig);
        if (ECDSA_sign(0, msg_hash, SHA512_DIGEST_LENGTH,
                       signature.data(), &sig_len, sign_key) != 1)
            throw std::runtime_error("ECDSA_sign failed");
        signature.resize(sig_len);
    });

    // -----------------------------------------------------------------------
    // STEP 7 — ECDSA VERIFY
    // Equivalent to Dilithium verify in the Kyber program
    // -----------------------------------------------------------------------
    BenchResult ver_data = measure([&]() {
        int ret = ECDSA_verify(0, msg_hash, SHA512_DIGEST_LENGTH,
                               signature.data(), (int)sig_len, sign_key);
        if (ret != 1) throw std::runtime_error("ECDSA_verify failed");
    });

    // -----------------------------------------------------------------------
    // Output — same DATA: prefix and CSV format as the Kyber program
    // -----------------------------------------------------------------------
    std::cout << "DATA:"
        << kg_data.cycles     << "," << kg_data.ns     << ","
        << ecdh_a_data.cycles << "," << ecdh_a_data.ns << ","
        << ecdh_b_data.cycles << "," << ecdh_b_data.ns << ","
        << sig_data.cycles    << "," << sig_data.ns    << ","
        << ver_data.cycles    << "," << ver_data.ns    << "\n";

    // Cleanup sensitive data
    OPENSSL_cleanse(k_enc_amy, 32);
    OPENSSL_cleanse(k_enc_bob, 32);
    OPENSSL_cleanse(ss_amy, sizeof(ss_amy));
    OPENSSL_cleanse(ss_bob, sizeof(ss_bob));
    OPENSSL_cleanse(decrypted.data(), decrypted.size());

    // Cleanup keys
    if (sign_key)     EC_KEY_free(sign_key);
    if (bob_kem_key)  EC_KEY_free(bob_kem_key);
    if (amy_ephemeral) EC_KEY_free(amy_ephemeral);

    return 0;
}
