import subprocess
import csv
import os

# --- Configuration ---
EXECUTABLE = "./exchange.exe"
INPUT_FILE = "input.txt"
OUTPUT_CSV = "benchmark_results.csv"

def run_benchmark():
    # 1. Compile the program using the Makefile
    print("🔨 Compiling with make...")
    try:
        subprocess.run(["make"], check=True, stdout=subprocess.DEVNULL)
    except subprocess.CalledProcessError:
        print("❌ Error: 'make' failed. Check your Makefile and C++ code.")
        return

    # 2. Parse input.txt for N (Iterations) and the Message
    if not os.path.exists(INPUT_FILE):
        print(f"❌ Error: {INPUT_FILE} not found. Please create it.")
        return
    
    with open(INPUT_FILE, "r") as f:
        lines = f.readlines()
        if not lines:
            print("❌ Error: input.txt is empty.")
            return
            
        # First line is N (Number of iterations)
        try:
            n_iterations = int(lines[0].strip())
        except ValueError:
            print("❌ Error: First line of input.txt must be an integer (N).")
            return
            
        # Remaining lines are the message content
        message_content = "".join(lines[1:])

    print(f"🚀 Starting {n_iterations} iterations based on input.txt...")
    header = ["Iter", "K_KEM_Cyc", "K_KEM_ns", "K_SIG_Cyc", "K_SIG_ns", 
          "Sign_Cyc", "Sign_ns", "Verify_Cyc", "Verify_ns", 
          "E_Cyc", "E_ns", "D_Cyc", "D_ns"]

    with open(OUTPUT_CSV, "w", newline="") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(header)

        for i in range(n_iterations):
            # Run exchange.exe and pipe the message_content into it
            process = subprocess.Popen(
                [EXECUTABLE],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            # Send the message and capture output
            stdout, stderr = process.communicate(input=message_content)

            # 3. Extract the DATA line
            found_data = False
            for line in stdout.splitlines():
                if line.startswith("DATA:"):
                    raw_values = line.replace("DATA:", "").strip().split(",")
                    writer.writerow([i + 1] + raw_values)
                    found_data = True
                    break
            
            if not found_data:
                print(f"⚠️ Warning: No DATA found in iteration {i+1}.")
                if stderr: print(f"Error: {stderr}")

            # Simple Progress Bar
            if (i + 1) % max(1, n_iterations // 20) == 0:
                percent = int(((i + 1) / n_iterations) * 100)
                print(f"⏳ Progress: {percent}% ({i + 1}/{n_iterations})")

    print(f"✨ Finished! Results saved to {OUTPUT_CSV}")

if __name__ == "__main__":
    run_benchmark()